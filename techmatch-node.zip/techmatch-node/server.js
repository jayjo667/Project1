// server.js — Backend ของเกม TECH MATCH
// รันด้วย Node.js (ไม่ต้องใช้ PHP/XAMPP อีกต่อไป)
// หน้าที่หลัก: เสิร์ฟไฟล์หน้าเว็บ (public/) + เก็บ/ดึงข้อมูล leaderboard ผ่าน API
//   GET  /api/leaderboard      -> คืนรายการ leaderboard ทั้งหมด (เรียงคะแนนมากไปน้อย)
//   POST /api/leaderboard      -> บันทึกผลการเล่นใหม่ 1 รายการ แล้วคืนรายการที่บันทึกพร้อม id

const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'leaderboard.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ----- ตัวช่วยอ่าน/เขียนไฟล์ข้อมูล -----
function seedInitialData() {
    // ข้อมูลตัวอย่างเริ่มต้น (ย้ายมาจาก mock data เดิมฝั่ง frontend)
    const mockNames = ['สมชาย', 'สมหญิง', 'กิตติศักดิ์', 'ณัฐพงษ์', 'พัชราภรณ์', 'ธนพล', 'อนันต์', 'ศิริพร', 'วรวุฒิ', 'อรพรรณ', 'ชลทิศ', 'นภา', 'ปฏิพัทธ์', 'วิภาวดี', 'รุ่งโรจน์'];
    const mockGrades = ['ม.4', 'ม.5', 'ม.6'];
    const mockRooms = ['ห้อง 1', 'ห้อง 2', 'ห้อง 3'];

    const data = Array.from({ length: 50 }, (_, i) => ({
        id: i + 1,
        name: `${mockNames[i % mockNames.length]} เจริญยิ่ง (ID: ${1024 + i})`,
        grade: mockGrades[i % mockGrades.length],
        room: mockRooms[(i + i % 2) % mockRooms.length],
        level: Math.floor(Math.random() * 15) + 1,
        moves: Math.floor(Math.random() * 18) + 8,
        score: Math.floor(Math.random() * 4500) + 1500,
        date: `2026-06-0${(i % 7) + 1}`
    })).sort((a, b) => b.score - a.score);

    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    return data;
}

function readLeaderboard() {
    if (!fs.existsSync(DATA_FILE)) {
        return seedInitialData();
    }
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (err) {
        console.error('ไฟล์ leaderboard.json เสียหาย กำลังสร้างใหม่:', err.message);
        return seedInitialData();
    }
}

function writeLeaderboard(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// ----- API Routes -----
app.get('/api/leaderboard', (req, res) => {
    const data = readLeaderboard();
    const sorted = [...data].sort((a, b) => b.score - a.score);
    res.json(sorted);
});

app.post('/api/leaderboard', (req, res) => {
    const { name, grade, room, level, moves, score, date } = req.body || {};

    // ตรวจสอบข้อมูลเบื้องต้นก่อนบันทึก
    if (!name || typeof score !== 'number' || typeof moves !== 'number' || typeof level !== 'number') {
        return res.status(400).json({ error: 'ข้อมูลที่ส่งมาไม่ครบหรือไม่ถูกต้อง' });
    }

    const data = readLeaderboard();
    const newEntry = {
        id: data.length ? Math.max(...data.map(d => d.id)) + 1 : 1,
        name: String(name).slice(0, 200),
        grade: grade || '',
        room: room || '',
        level,
        moves,
        score,
        date: date || new Date().toISOString().split('T')[0]
    };

    data.push(newEntry);
    writeLeaderboard(data);
    res.status(201).json(newEntry);
});

// เส้นทางอื่นๆ ที่ไม่ตรงกับไฟล์ static หรือ API ให้ส่งกลับไปหน้าเกมหลัก (SPA fallback)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🧠 TECH MATCH server กำลังทำงานที่ http://localhost:${PORT}`);
});
